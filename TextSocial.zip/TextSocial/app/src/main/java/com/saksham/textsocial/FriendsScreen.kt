package com.saksham.textsocial

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun SectionLabel(text: String, color: androidx.compose.ui.graphics.Color) {
    Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp)
}

@Composable
fun FriendsScreen() {
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<ProfileRow>>(emptyList()) }
    var incoming by remember { mutableStateOf<List<Pair<FriendReqRow, ProfileRow?>>>(emptyList()) }
    var friends by remember { mutableStateOf<List<ProfileRow>>(emptyList()) }
    var info by remember { mutableStateOf<String?>(null) }

    fun load() {
        scope.launch {
            runCatching { incoming = Backend.incomingRequests(); friends = Backend.friends() }
                .onFailure { info = it.message }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ScreenTitle("Friends") {
            IconButton(onClick = { load() }) { Icon(Icons.Filled.Refresh, null, tint = g.sub) }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            query, { query = it }, placeholder = { Text("Username se dhundo") },
                            singleLine = true, colors = glassFieldColors(), modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            scope.launch {
                                runCatching { Backend.searchUsers(query.trim()) }
                                    .onSuccess { results = it; info = if (it.isEmpty()) "Koi user nahi mila" else null }
                                    .onFailure { info = it.message }
                            }
                        }) { Icon(Icons.Filled.Search, null, tint = Red) }
                    }
                }
            }
            info?.let { item { Text(it, color = Yellow, fontSize = 13.sp) } }

            if (results.isNotEmpty()) {
                item { SectionLabel("Search results", g.sub) }
                items(results, key = { "s" + it.id }) { p ->
                    PersonRow("@" + p.username, p.display_name) {
                        SmallButton("Add", Green) {
                            scope.launch {
                                runCatching { Backend.sendRequest(p.id) }
                                    .onSuccess { info = "Request bhej di" }
                                    .onFailure { info = it.message ?: "Error" }
                            }
                        }
                    }
                }
            }

            if (incoming.isNotEmpty()) {
                item { SectionLabel("Incoming requests", Yellow) }
                items(incoming, key = { "r" + it.first.id }) { (req, prof) ->
                    PersonRow("@" + (prof?.username ?: "user"), null, Yellow) {
                        SmallButton("Accept", Green) {
                            scope.launch {
                                runCatching { Backend.respond(req.id, "accepted") }
                                    .onSuccess { load() }.onFailure { info = it.message }
                            }
                        }
                        TextButton(onClick = {
                            scope.launch {
                                runCatching { Backend.respond(req.id, "rejected") }
                                    .onSuccess { load() }.onFailure { info = it.message }
                            }
                        }) { Text("No", color = g.sub) }
                    }
                }
            }

            item { SectionLabel("Your friends", Green) }
            items(friends, key = { "f" + it.id }) { f ->
                PersonRow("@" + f.username, f.display_name, Green)
            }
            if (friends.isEmpty()) item { EmptyNote("Abhi koi friend nahi. Upar search karke add karo.") }
        }
    }
}
