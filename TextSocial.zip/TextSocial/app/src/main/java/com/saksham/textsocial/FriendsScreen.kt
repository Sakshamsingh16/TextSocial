package com.saksham.textsocial

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun FriendsScreen(initialTab: Int = 0, onOpenChat: (ChatTarget) -> Unit) {
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(initialTab) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<ProfileRow>>(emptyList()) }
    var sent by remember { mutableStateOf<Set<String>>(emptySet()) }
    var incoming by remember { mutableStateOf<List<Pair<FriendReqRow, ProfileRow?>>>(emptyList()) }
    var friends by remember { mutableStateOf<List<ProfileRow>>(emptyList()) }
    var chats by remember { mutableStateOf<List<ChatTarget>>(emptyList()) }
    var info by remember { mutableStateOf<String?>(null) }

    fun load() {
        scope.launch {
            runCatching {
                incoming = Backend.incomingRequests()
                friends = Backend.friends()
                chats = Backend.chats()
            }.onFailure { info = it.message }
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ScreenTitle("Friends") {
            IconButton(onClick = { load() }) { Icon(Icons.Filled.Refresh, null, tint = g.sub) }
        }
        PillTabs(listOf("Friends ${friends.size}", "Requests ${incoming.size}", "Find"), tab) { tab = it; info = null }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            info?.let { item { Text(it, color = Yellow, fontSize = 13.sp) } }

            when (tab) {
                0 -> {
                    items(friends, key = { "f" + it.id }) { f ->
                        PersonRow("@" + f.username, f.display_name ?: "Friend", Green) {
                            SmallButton("Chat", Green) {
                                val t = chats.firstOrNull { it.userId == f.id }
                                if (t != null) onOpenChat(t) else { info = "Chat is getting ready, tap refresh"; load() }
                            }
                        }
                    }
                    if (friends.isEmpty()) item { EmptyNote("No friends yet. Use the Find tab to add some.", "\uD83D\uDC65") }
                }
                1 -> {
                    items(incoming, key = { "r" + it.first.id }) { (req, prof) ->
                        PersonRow("@" + (prof?.username ?: "user"), "wants to be your friend", Yellow) {
                            SmallButton("Accept", Green) {
                                scope.launch {
                                    runCatching { Backend.respond(req.id, "accepted") }
                                        .onSuccess { load() }.onFailure { info = it.message }
                                }
                            }
                            TextButton(onClick = {
                                scope.launch {
                                    runCatching { Backend.respond(req.id, "rejected") }
                                        .onSuccess { load() }.onFailure { info = it.message }
                                }
                            }) { Text("No", color = g.sub) }
                        }
                    }
                    if (incoming.isEmpty()) item { EmptyNote("No pending requests.", "\uD83D\uDCED") }
                }
                else -> {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                query, { query = it }, placeholder = { Text("Search username") },
                                singleLine = true, shape = RoundedCornerShape(20.dp),
                                colors = glassFieldColors(), modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = {
                                scope.launch {
                                    runCatching { Backend.searchUsers(query.trim()) }
                                        .onSuccess { results = it; info = if (it.isEmpty()) "No user found" else null }
                                        .onFailure { info = it.message }
                                }
                            }) { Icon(Icons.Filled.Search, null, tint = Red) }
                        }
                    }
                    items(results, key = { "s" + it.id }) { p ->
                        val already = friends.any { it.id == p.id }
                        PersonRow("@" + p.username, p.display_name) {
                            when {
                                already -> Text("Friends", color = Green, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                                p.id in sent -> Text("Sent", color = g.sub)
                                else -> SmallButton("Add", Green) {
                                    scope.launch {
                                        runCatching { Backend.sendRequest(p.id) }
                                            .onSuccess { sent = sent + p.id; info = null }
                                            .onFailure { info = it.message ?: "Error" }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
