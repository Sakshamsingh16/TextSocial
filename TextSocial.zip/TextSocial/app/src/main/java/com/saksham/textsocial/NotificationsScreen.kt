package com.saksham.textsocial

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun notifTitle(n: NotifItem): String {
    val who = n.actor?.let { "@$it" } ?: "Someone"
    return when (n.row.type) {
        "like" -> "$who liked your post"
        "reply" -> "$who replied to your post"
        "comment_reply" -> "$who replied to your comment"
        "friend_request" -> "$who sent you a friend request"
        "friend_accept" -> "$who accepted your friend request"
        "message" -> "$who sent you a message"
        else -> "New notification"
    }
}

fun notifBody(n: NotifItem): String = n.row.preview ?: ""

private fun notifEmoji(type: String): Pair<String, Color> = when (type) {
    "like" -> "\u2764\uFE0F" to Red
    "reply", "comment_reply" -> "\uD83D\uDCAC" to Yellow
    "friend_request" -> "\uD83D\uDC4B" to Green
    "friend_accept" -> "\uD83E\uDD1D" to Green
    "message" -> "\u2709\uFE0F" to Red
    else -> "\uD83D\uDD14" to Yellow
}

@Composable
fun NotificationsScreen(list: List<NotifItem>, onMarkAll: () -> Unit, onTap: (NotifItem) -> Unit) {
    val g = LocalGlass.current
    val unread = list.count { it.row.read_at == null }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ScreenTitle("Alerts") {
            if (unread > 0) TextButton(onClick = onMarkAll) { Text("Mark all read", color = Red, fontWeight = FontWeight.Bold) }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list, key = { it.row.id }) { n ->
                val isNew = n.row.read_at == null
                val (emoji, tint) = notifEmoji(n.row.type)
                GlassCard(Modifier.fillMaxWidth(), onClick = { onTap(n) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(44.dp).clip(CircleShape).background(tint.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) { Text(emoji, fontSize = 20.sp) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                notifTitle(n), color = g.text,
                                fontWeight = if (isNew) FontWeight.Bold else FontWeight.Normal
                            )
                            val body = notifBody(n)
                            if (body.isNotBlank()) Text(body, color = g.sub, fontSize = 13.sp, maxLines = 2)
                            Text(timeAgo(n.row.created_at), color = g.sub, fontSize = 11.sp)
                        }
                        if (isNew) Box(Modifier.size(10.dp).clip(CircleShape).background(Red))
                    }
                }
            }
            if (list.isEmpty()) item { EmptyNote("No alerts yet. Likes, replies, requests and messages show up here.", "\uD83D\uDD14") }
        }
    }
}
