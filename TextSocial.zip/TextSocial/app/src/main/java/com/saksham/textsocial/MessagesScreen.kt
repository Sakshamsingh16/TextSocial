package com.saksham.textsocial

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun MessagesScreen(unread: Set<String>, onOpen: (ChatTarget) -> Unit) {
    val g = LocalGlass.current
    var chats by remember { mutableStateOf<List<ChatTarget>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        runCatching { Backend.chats() }.onSuccess { chats = it }.onFailure { info = it.message }
        loaded = true
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ScreenTitle("Messages")
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            info?.let { item { Text("Error: $it", color = Red, fontSize = 13.sp) } }
            items(chats, key = { it.cid }) { c ->
                val hasNew = c.cid in unread
                PersonRow("@" + c.name, if (hasNew) "New message" else "Tap to chat", if (hasNew) Red else Green, onClick = { onOpen(c) }) {
                    if (hasNew) Box(Modifier.size(12.dp).clip(RoundedCornerShape(6.dp)).background(Red))
                }
            }
            if (loaded && chats.isEmpty() && info == null) item {
                EmptyNote("Chats open with accepted friends. Add a friend first.", "\uD83D\uDCE8")
            }
        }
    }
}

@Composable
fun Bubble(m: MessageRow, mine: Boolean) {
    val g = LocalGlass.current
    val shape = if (mine) RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp) else RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 290.dp).clip(shape)
                .background(
                    if (mine) Brush.linearGradient(listOf(Red, Coral))
                    else Brush.linearGradient(listOf(g.card, g.card))
                )
                .border(1.dp, if (mine) Color.Transparent else g.border, shape)
                .padding(horizontal = 14.dp, vertical = 9.dp)
        ) {
            Text(m.body, color = if (mine) Color.White else g.text)
            Text(
                timeAgo(m.created_at), fontSize = 10.sp,
                color = if (mine) Color.White.copy(alpha = 0.75f) else g.sub
            )
        }
    }
}

@Composable
fun ChatRoomScreen(target: ChatTarget, onBack: () -> Unit) {
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var msgs by remember { mutableStateOf<List<MessageRow>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var askBlock by remember { mutableStateOf(false) }
    val me = Backend.uid

    // Every 3 seconds refresh (polling). Realtime later.
    LaunchedEffect(target.cid) {
        while (true) {
            runCatching { Backend.messages(target.cid) }.onSuccess { msgs = it; error = null }
            delay(3000)
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = g.text) }
            Avatar(target.name, Green, 38.dp)
            Text(
                "  @" + target.name, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                color = g.text, modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { askBlock = true }) { Text("Block", color = Red) }
        }
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 12.dp),
            reverseLayout = true,
            contentPadding = PaddingValues(vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(msgs, key = { it.id }) { m -> Bubble(m, m.sender_id == me) }
        }
        error?.let { Text("Error: $it", color = Red, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp)) }
        Row(
            Modifier.fillMaxWidth().padding(10.dp).navigationBarsPadding(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                text, { if (it.length <= 2000) text = it },
                placeholder = { Text("Write a message...") }, shape = RoundedCornerShape(26.dp),
                colors = glassFieldColors(), modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(50.dp).clip(RoundedCornerShape(25.dp))
                    .background(Brush.linearGradient(listOf(Red, Coral)))
                    .clickable(enabled = text.isNotBlank()) {
                        val body = text.trim()
                        text = ""
                        scope.launch {
                            runCatching { Backend.sendMessage(target.cid, body) }
                                .onSuccess { runCatching { Backend.messages(target.cid) }.onSuccess { msgs = it } }
                                .onFailure { error = it.message; text = body }
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White) }
        }
    }

    if (askBlock) {
        AlertDialog(
            onDismissRequest = { askBlock = false },
            title = { Text("Block @${target.name}?") },
            text = { Text("Blocking removes the friendship and they can no longer message you.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { runCatching { Backend.block(target.userId) }; askBlock = false; onBack() }
                }) { Text("Block", color = Red) }
            },
            dismissButton = { TextButton(onClick = { askBlock = false }) { Text("Cancel") } }
        )
    }
}
