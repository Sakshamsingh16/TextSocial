package com.saksham.textsocial

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun MessagesScreen(onOpen: (ChatTarget) -> Unit) {
    var chats by remember { mutableStateOf<List<ChatTarget>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        runCatching { Backend.chats() }.onSuccess { chats = it }.onFailure { info = it.message }
        loaded = true
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ScreenTitle("Messages")
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            info?.let { item { Text("Error: $it", color = Red, fontSize = 13.sp) } }
            items(chats, key = { it.cid }) { c ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { onOpen(c) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c.name, Green)
                        Text(
                            "   @" + c.name, color = LocalGlass.current.text,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            if (loaded && chats.isEmpty() && info == null) item {
                EmptyNote("Chat sirf accepted friends ke saath hoti hai. Pehle friend banao.")
            }
        }
    }
}

@Composable
fun Bubble(m: MessageRow, mine: Boolean) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(18.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier.widthIn(max = 280.dp).clip(shape)
                .background(if (mine) Red.copy(alpha = 0.85f) else g.card)
                .border(1.dp, if (mine) Color.Transparent else g.border, shape)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Text(m.body, color = if (mine) Color.White else g.text)
            Text(
                timeAgo(m.created_at), fontSize = 10.sp,
                color = if (mine) Color.White.copy(alpha = 0.7f) else g.sub
            )
        }
    }
}

@Composable
fun ChatRoomScreen(target: ChatTarget, onBack: () -> Unit) {
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var msgs by remember { mutableStateOf<List<MessageRow>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var askBlock by remember { mutableStateOf(false) }
    val me = Backend.uid

    // Abhi har 3 second me refresh (polling). Realtime baad me jodenge.
    LaunchedEffect(target.cid) {
        while (true) {
            runCatching { Backend.messages(target.cid) }.onSuccess { msgs = it; error = null }
            delay(3000)
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = g.text) }
            Text("@" + target.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = g.text, modifier = Modifier.weight(1f))
            TextButton(onClick = { askBlock = true }) { Text("Block", color = Red) }
        }
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 12.dp),
            reverseLayout = true,
            contentPadding = PaddingValues(vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(msgs, key = { it.id }) { m -> Bubble(m, m.sender_id == me) }
        }
        error?.let { Text("Error: $it", color = Red, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp)) }
        GlassCard(Modifier.fillMaxWidth().padding(10.dp).navigationBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    text, { if (it.length <= 2000) text = it },
                    placeholder = { Text("Write a message...") },
                    colors = glassFieldColors(), modifier = Modifier.weight(1f)
                )
                IconButton(enabled = text.isNotBlank(), onClick = {
                    val body = text.trim()
                    text = ""
                    scope.launch {
                        runCatching { Backend.sendMessage(target.cid, body) }
                            .onSuccess { runCatching { Backend.messages(target.cid) }.onSuccess { msgs = it } }
                            .onFailure { error = it.message; text = body }
                    }
                }) { Icon(Icons.AutoMirrored.Filled.Send, null, tint = Red) }
            }
        }
    }

    if (askBlock) {
        AlertDialog(
            onDismissRequest = { askBlock = false },
            title = { Text("@${target.name} ko block karein?") },
            text = { Text("Block karne par friendship hat jayegi aur wo message nahi bhej payega.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { runCatching { Backend.block(target.userId) }; askBlock = false; onBack() }
                }) { Text("Block", color = Red) }
            },
            dismissButton = { TextButton(onClick = { askBlock = false }) { Text("Cancel") } }
        )
    }
}
