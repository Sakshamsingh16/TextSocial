package com.saksham.textsocial

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Teen colors: Red (main), Green (accept/online), Yellow (anonymous/highlight)
val Red = Color(0xFFFF4D5E)
val Green = Color(0xFF2ECC71)
val Yellow = Color(0xFFFFC53D)

class Glass(val dark: Boolean) {
    val card = if (dark) Color.White.copy(alpha = 0.07f) else Color.White.copy(alpha = 0.62f)
    val border = if (dark) Color.White.copy(alpha = 0.14f) else Color.Black.copy(alpha = 0.08f)
    val text = if (dark) Color(0xFFF2F2F6) else Color(0xFF1B1B22)
    val sub = if (dark) Color(0xFFA6A8B5) else Color(0xFF666878)
    val bg: List<Color> = if (dark)
        listOf(Color(0xFF0D0E13), Color(0xFF1A1017), Color(0xFF0E1A15))
    else
        listOf(Color(0xFFFFF6F1), Color(0xFFFFEFE2), Color(0xFFEFFAF1))
}

val LocalGlass = staticCompositionLocalOf { Glass(true) }

// mode: 0 = system, 1 = day, 2 = night
@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val g = remember(dark) { Glass(dark) }
    val scheme = if (dark) darkColorScheme(
        primary = Red, secondary = Green, tertiary = Yellow,
        background = g.bg[0], surface = g.bg[0], onSurface = g.text, onBackground = g.text
    ) else lightColorScheme(
        primary = Red, secondary = Green, tertiary = Yellow,
        background = g.bg[0], surface = g.bg[0], onSurface = g.text, onBackground = g.text
    )
    CompositionLocalProvider(LocalGlass provides g) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    val g = LocalGlass.current
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(g.bg))) {
        Box(
            Modifier.size(340.dp).offset((-90).dp, (-70).dp)
                .background(Brush.radialGradient(listOf(Red.copy(alpha = 0.30f), Color.Transparent)))
        )
        Box(
            Modifier.size(300.dp).align(androidx.compose.ui.Alignment.BottomEnd).offset(90.dp, 60.dp)
                .background(Brush.radialGradient(listOf(Green.copy(alpha = 0.22f), Color.Transparent)))
        )
        Box(
            Modifier.size(220.dp).align(androidx.compose.ui.Alignment.CenterEnd).offset(80.dp, (-80).dp)
                .background(Brush.radialGradient(listOf(Yellow.copy(alpha = 0.16f), Color.Transparent)))
        )
        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(20.dp)
    var m = modifier.clip(shape).background(g.card).border(1.dp, g.border, shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(14.dp), content = content)
}
