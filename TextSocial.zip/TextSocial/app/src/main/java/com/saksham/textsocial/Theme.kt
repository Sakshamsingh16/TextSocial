package com.saksham.textsocial

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp

// Teen colors: Red (main), Green (accept/online), Yellow (anonymous/highlight)
val Red = Color(0xFFFF4D5E)
val Green = Color(0xFF2ECC71)
val Yellow = Color(0xFFFFC53D)
val Coral = Color(0xFFFF7A59)

val BrandBrush = Brush.horizontalGradient(listOf(Red, Coral, Yellow))

class Glass(val dark: Boolean) {
    val card = if (dark) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.68f)
    val border = if (dark) Color.White.copy(alpha = 0.10f) else Color.Black.copy(alpha = 0.06f)
    val borderHi = if (dark) Color.White.copy(alpha = 0.30f) else Color.White.copy(alpha = 0.95f)
    val text = if (dark) Color(0xFFF4F4F8) else Color(0xFF1B1B22)
    val sub = if (dark) Color(0xFFA9ABB8) else Color(0xFF666878)
    val bg: List<Color> = if (dark)
        listOf(Color(0xFF0C0D12), Color(0xFF1B1018), Color(0xFF0D1A14))
    else
        listOf(Color(0xFFFFF5F0), Color(0xFFFFEEDF), Color(0xFFEAF9EF))
}

val LocalGlass = staticCompositionLocalOf { Glass(true) }

// mode: 0 = system, 1 = day, 2 = night
@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val g = remember(dark) { Glass(dark) }
    val scheme = if (dark) darkColorScheme(
        primary = Red, secondary = Green, tertiary = Yellow,
        background = g.bg[0], surface = g.bg[0], onSurface = g.text, onBackground = g.text
    ) else lightColorScheme(
        primary = Red, secondary = Green, tertiary = Yellow,
        background = g.bg[0], surface = g.bg[0], onSurface = g.text, onBackground = g.text
    )
    CompositionLocalProvider(LocalGlass provides g) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    val g = LocalGlass.current
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(g.bg))) {
        Box(
            Modifier.size(380.dp).offset((-110).dp, (-90).dp)
                .background(Brush.radialGradient(listOf(Red.copy(alpha = 0.32f), Color.Transparent)))
        )
        Box(
            Modifier.size(340.dp).align(Alignment.BottomEnd).offset(110.dp, 80.dp)
                .background(Brush.radialGradient(listOf(Green.copy(alpha = 0.24f), Color.Transparent)))
        )
        Box(
            Modifier.size(260.dp).align(Alignment.CenterEnd).offset(100.dp, (-60).dp)
                .background(Brush.radialGradient(listOf(Yellow.copy(alpha = 0.18f), Color.Transparent)))
        )
        content()
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(24.dp)
    var m = modifier.clip(shape)
        .background(Brush.verticalGradient(listOf(g.card, g.card.copy(alpha = g.card.alpha * 0.55f))))
        .border(1.dp, Brush.linearGradient(listOf(g.borderHi, g.border)), shape)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun BrandText(text: String, size: TextUnit) {
    Text(text, style = TextStyle(brush = BrandBrush, fontSize = size, fontWeight = FontWeight.ExtraBold))
}
