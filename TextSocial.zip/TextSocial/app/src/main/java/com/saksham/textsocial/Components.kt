package com.saksham.textsocial

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.OffsetDateTime

fun timeAgo(iso: String): String = runCatching {
    val s = (System.currentTimeMillis() - OffsetDateTime.parse(iso).toInstant().toEpochMilli()) / 1000
    when {
        s < 60 -> "abhi"
        s < 3600 -> "${s / 60}m"
        s < 86400 -> "${s / 3600}h"
        else -> "${s / 86400}d"
    }
}.getOrDefault("")

@Composable
fun glassFieldColors(): TextFieldColors {
    val g = LocalGlass.current
    return OutlinedTextFieldDefaults.colors(
        focusedTextColor = g.text, unfocusedTextColor = g.text,
        focusedBorderColor = Red, unfocusedBorderColor = g.border,
        cursorColor = Red, focusedLabelColor = Red, unfocusedLabelColor = g.sub,
        focusedPlaceholderColor = g.sub, unfocusedPlaceholderColor = g.sub
    )
}

@Composable
fun SmallButton(text: String, color: Color = Red, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = color, contentColor = Color.White,
            disabledContainerColor = color.copy(alpha = 0.35f), disabledContentColor = Color.White.copy(alpha = 0.7f)
        ),
        shape = RoundedCornerShape(14.dp)
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun ScreenTitle(title: String, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = LocalGlass.current.text, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
fun Avatar(name: String, tint: Color = Red) {
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(tint.copy(alpha = 0.22f)).border(1.dp, tint.copy(alpha = 0.6f), CircleShape),
        contentAlignment = Alignment.Center
    ) { Text(name.trimStart('@').take(1).uppercase(), color = tint, fontWeight = FontWeight.Bold) }
}

@Composable
fun EmptyNote(text: String) {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = LocalGlass.current.sub)
    }
}

@Composable
fun PersonRow(title: String, sub: String? = null, tint: Color = Red, trailing: @Composable RowScope.() -> Unit = {}) {
    val g = LocalGlass.current
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(title, tint)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = g.text, fontWeight = FontWeight.SemiBold)
                if (sub != null) Text(sub, color = g.sub, fontSize = 12.sp)
            }
            trailing()
        }
    }
}
