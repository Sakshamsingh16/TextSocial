package com.saksham.textsocial

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.OffsetDateTime

fun timeAgo(iso: String): String = runCatching {
    val s = (System.currentTimeMillis() - OffsetDateTime.parse(iso).toInstant().toEpochMilli()) / 1000
    when {
        s < 60 -> "now"
        s < 3600 -> "${s / 60}m"
        s < 86400 -> "${s / 3600}h"
        else -> "${s / 86400}d"
    }
}.getOrDefault("")

@Composable
fun glassFieldColors(): TextFieldColors {
    val g = LocalGlass.current
    return OutlinedTextFieldDefaults.colors(
        focusedTextColor = g.text, unfocusedTextColor = g.text,
        focusedBorderColor = Red, unfocusedBorderColor = g.border,
        cursorColor = Red, focusedLabelColor = Red, unfocusedLabelColor = g.sub,
        focusedPlaceholderColor = g.sub, unfocusedPlaceholderColor = g.sub,
        focusedContainerColor = g.card.copy(alpha = 0.5f), unfocusedContainerColor = g.card.copy(alpha = 0.35f)
    )
}

@Composable
fun SmallButton(text: String, color: Color = Red, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val end = if (color == Red) Coral else color.copy(alpha = 0.75f)
    Box(
        modifier.alpha(if (enabled) 1f else 0.4f)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(color, end)))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold) }
}

@Composable
fun ScreenTitle(title: String, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = LocalGlass.current.text, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
fun Avatar(name: String, tint: Color = Red, size: Dp = 44.dp, anonymous: Boolean = false) {
    val g = LocalGlass.current
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(listOf(tint, tint.copy(alpha = 0.25f))))
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape).background(g.bg[0]).background(tint.copy(alpha = 0.20f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (anonymous) "\uD83C\uDFAD" else name.trimStart('@').take(1).uppercase(),
                color = tint, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.4f).sp
            )
        }
    }
}

@Composable
fun EmptyNote(text: String, emoji: String = "\u2728") {
    Column(Modifier.fillMaxWidth().padding(36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 40.sp)
        Spacer(Modifier.height(8.dp))
        Text(text, color = LocalGlass.current.sub, textAlign = TextAlign.Center)
    }
}

@Composable
fun PillTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth()
            .clip(shape).background(g.card).border(1.dp, g.border, shape).padding(4.dp)
    ) {
        labels.forEachIndexed { i, label ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                    .background(if (sel) Brush.horizontalGradient(listOf(Red, Coral)) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)))
                    .clickable { onSelect(i) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (sel) Color.White else g.sub, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun CountBadge(count: Int) {
    Box(
        Modifier.defaultMinSize(minWidth = 18.dp, minHeight = 18.dp).clip(CircleShape).background(Red).padding(horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) { Text(if (count > 9) "9+" else "$count", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun PersonRow(
    title: String, sub: String? = null, tint: Color = Red, onClick: (() -> Unit)? = null,
    trailing: @Composable RowScope.() -> Unit = {}
) {
    val g = LocalGlass.current
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(title, tint)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = g.text, fontWeight = FontWeight.Bold)
                if (sub != null) Text(sub, color = g.sub, fontSize = 12.sp)
            }
            trailing()
        }
    }
}
