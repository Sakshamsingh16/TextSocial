package com.saksham.textsocial

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun AnonSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = LocalGlass.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Yellow, checkedThumbColor = Color.White)
        )
        Spacer(Modifier.width(8.dp))
        Text("Anonymous", color = if (checked) Yellow else g.sub, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun PostCard(p: PostRow, onClick: (() -> Unit)?, onLike: (() -> Unit)?) {
    val g = LocalGlass.current
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val name = if (p.is_anonymous) "Anonymous" else "@" + (p.username ?: p.display_name ?: "user")
            Text(
                name, color = if (p.is_anonymous) Yellow else g.text,
                fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
            )
            if (p.is_mine && p.is_anonymous) Text("tumhari  ", color = g.sub, fontSize = 11.sp)
            Text(timeAgo(p.created_at), color = g.sub, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(p.body, color = g.text)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            val liked = p.liked_by_me
            Icon(
                if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                tint = if (liked) Red else g.sub,
                modifier = Modifier.size(22.dp).clickable(enabled = onLike != null) { onLike?.invoke() }
            )
            Text("  ${p.like_count}", color = g.sub)
            Spacer(Modifier.width(20.dp))
            Text("\uD83D\uDCAC ${p.reply_count}", color = g.sub)
        }
    }
}

@Composable
fun HomeScreen(onOpenPost: (PostRow) -> Unit) {
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var posts by remember { mutableStateOf<List<PostRow>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var anon by remember { mutableStateOf(false) }
    var posting by remember { mutableStateOf(false) }

    fun load() {
        scope.launch {
            loading = true
            runCatching { Backend.feed() }
                .onSuccess { posts = it; error = null }
                .onFailure { error = it.message }
            loading = false
        }
    }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ScreenTitle("Home") {
            IconButton(onClick = { load() }) { Icon(Icons.Filled.Refresh, null, tint = g.sub) }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        text, { if (it.length <= 2000) text = it },
                        placeholder = { Text("What's on your mind?") },
                        colors = glassFieldColors(), modifier = Modifier.fillMaxWidth(), minLines = 2
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { AnonSwitch(anon) { anon = it } }
                        Text("${text.length}/2000  ", color = g.sub, fontSize = 11.sp)
                        SmallButton("Post", enabled = text.isNotBlank() && !posting) {
                            scope.launch {
                                posting = true
                                runCatching { Backend.createPost(text.trim(), anon) }
                                    .onSuccess { text = ""; anon = false; load() }
                                    .onFailure { error = it.message }
                                posting = false
                            }
                        }
                    }
                }
            }
            error?.let { item { Text("Error: $it", color = Red, fontSize = 13.sp) } }
            if (loading && posts.isEmpty()) item {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Red)
                }
            }
            items(posts, key = { it.id }) { p ->
                PostCard(p, onClick = { onOpenPost(p) }, onLike = {
                    val nl = !p.liked_by_me
                    posts = posts.map {
                        if (it.id == p.id) it.copy(liked_by_me = nl, like_count = it.like_count + (if (nl) 1 else -1)) else it
                    }
                    scope.launch { runCatching { Backend.setLike(p.id, nl) }.onFailure { load() } }
                })
            }
            if (!loading && posts.isEmpty() && error == null) item { EmptyNote("Abhi koi post nahi. Pehli post tum karo!") }
        }
    }
}

private fun flatten(rs: List<ReplyRow>): List<Pair<ReplyRow, Int>> {
    val byParent = rs.groupBy { it.parent_reply_id }
    val out = mutableListOf<Pair<ReplyRow, Int>>()
    fun walk(parent: String?, depth: Int) {
        byParent[parent]?.forEach { out.add(it to depth); walk(it.id, depth + 1) }
    }
    walk(null, 0)
    return out
}

@Composable
fun PostDetailScreen(post: PostRow, onBack: () -> Unit) {
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var replies by remember { mutableStateOf<List<ReplyRow>>(emptyList()) }
    var replyTo by remember { mutableStateOf<ReplyRow?>(null) }
    var text by remember { mutableStateOf("") }
    var anon by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load() {
        scope.launch {
            runCatching { Backend.replies(post.id) }
                .onSuccess { replies = it; error = null }
                .onFailure { error = it.message }
        }
    }
    LaunchedEffect(post.id) { load() }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = g.text) }
            Text("Discussion", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = g.text)
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { PostCard(post, null, null) }
            error?.let { item { Text("Error: $it", color = Red, fontSize = 13.sp) } }
            items(flatten(replies), key = { it.first.id }) { (r, depth) ->
                GlassCard(Modifier.fillMaxWidth().padding(start = (minOf(depth, 4) * 14).dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val name = if (r.is_anonymous) "Anonymous" else "@" + (r.username ?: "user")
                        Text(
                            name, color = if (r.is_anonymous) Yellow else g.text,
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                        )
                        Text(timeAgo(r.created_at), color = g.sub, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(r.body, color = g.text)
                    Text(
                        "Reply", color = Red, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 6.dp).clickable { replyTo = r }
                    )
                }
            }
            if (replies.isEmpty() && error == null) item { EmptyNote("Abhi koi reply nahi") }
        }
        GlassCard(Modifier.fillMaxWidth().padding(10.dp).navigationBarsPadding()) {
            replyTo?.let {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Replying to " + (if (it.is_anonymous) "Anonymous" else "@" + (it.username ?: "user")),
                        color = Yellow, fontSize = 12.sp, modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { replyTo = null }) { Text("Cancel", color = g.sub) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    text, { if (it.length <= 1000) text = it },
                    placeholder = { Text("Reply likho...") },
                    colors = glassFieldColors(), modifier = Modifier.weight(1f)
                )
                IconButton(
                    enabled = text.isNotBlank() && !sending,
                    onClick = {
                        scope.launch {
                            sending = true
                            runCatching { Backend.addReply(post.id, replyTo?.id, text.trim(), anon) }
                                .onSuccess { text = ""; replyTo = null; load() }
                                .onFailure { error = it.message }
                            sending = false
                        }
                    }
                ) { Icon(Icons.AutoMirrored.Filled.Send, null, tint = Red) }
            }
            AnonSwitch(anon) { anon = it }
        }
    }
}
