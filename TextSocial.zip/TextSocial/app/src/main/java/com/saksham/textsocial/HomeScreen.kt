package com.saksham.textsocial

import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch

@Composable
fun AnonSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.clip(shape)
            .background(if (checked) Yellow.copy(alpha = 0.18f) else g.card)
            .border(1.dp, if (checked) Yellow else g.border, shape)
            .clickable { onChange(!checked) }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("\uD83C\uDFAD ", fontSize = 15.sp)
        Text("Anonymous", color = if (checked) Yellow else g.sub, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
fun ItemMenu(isMine: Boolean, onReport: () -> Unit, onDelete: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    val g = LocalGlass.current
    Box {
        Icon(Icons.Filled.MoreVert, null, tint = g.sub, modifier = Modifier.size(24.dp).clickable { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (isMine) DropdownMenuItem(text = { Text("Delete") }, onClick = { open = false; onDelete() })
            else DropdownMenuItem(text = { Text("Report") }, onClick = { open = false; onReport() })
        }
    }
}

@Composable
fun PostCard(
    p: PostRow, onClick: (() -> Unit)?, onLike: (() -> Unit)?,
    onReport: (() -> Unit)? = null, onDelete: (() -> Unit)? = null
) {
    val g = LocalGlass.current
    val anon = p.is_anonymous
    val name = if (anon) "Anonymous" else "@" + (p.username ?: p.display_name ?: "user")
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(name, if (anon) Yellow else Red, 40.dp, anonymous = anon)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = if (anon) Yellow else g.text, fontWeight = FontWeight.Bold)
                Text(
                    timeAgo(p.created_at) + (if (p.is_mine && anon) "  \u00B7  only you know it's you" else ""),
                    color = g.sub, fontSize = 12.sp
                )
            }
            if (onReport != null || onDelete != null) ItemMenu(p.is_mine, { onReport?.invoke() }, { onDelete?.invoke() })
        }
        Spacer(Modifier.height(12.dp))
        Text(p.body, color = g.text, fontSize = 16.sp, lineHeight = 22.sp)
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            val liked = p.liked_by_me
            val scale by animateFloatAsState(
                if (liked) 1.18f else 1f, spring(dampingRatio = Spring.DampingRatioHighBouncy), label = "like"
            )
            Row(
                Modifier.clip(RoundedCornerShape(14.dp))
                    .background(if (liked) Red.copy(alpha = 0.16f) else g.card)
                    .clickable(enabled = onLike != null) { onLike?.invoke() }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                    tint = if (liked) Red else g.sub,
                    modifier = Modifier.size(20.dp).graphicsLayer(scaleX = scale, scaleY = scale)
                )
                Text("  ${p.like_count}", color = if (liked) Red else g.sub, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.width(10.dp))
            Row(
                Modifier.clip(RoundedCornerShape(14.dp)).background(g.card).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("\uD83D\uDCAC ${p.reply_count}", color = g.sub, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun HomeScreen(onOpenPost: (PostRow) -> Unit) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var posts by remember { mutableStateOf<List<PostRow>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var showCompose by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var anon by remember { mutableStateOf(false) }
    var posting by remember { mutableStateOf(false) }

    fun load() {
        scope.launch {
            loading = true
            runCatching {
                when (tab) {
                    1 -> Backend.feed().sortedWith(
                        compareByDescending<PostRow> { it.like_count * 3 + it.reply_count * 2 }.thenByDescending { it.created_at }
                    )
                    2 -> Backend.feedFriends(Backend.friends().map { it.id })
                    else -> Backend.feed()
                }
            }.onSuccess { posts = it; error = null }.onFailure { error = it.message }
            loading = false
        }
    }
    LaunchedEffect(tab) { load() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { BrandText("Text Social", 28.sp) }
            IconButton(onClick = { load() }) { Icon(Icons.Filled.Refresh, null, tint = g.sub) }
        }
        PillTabs(listOf("Latest", "Trending", "Friends"), tab) { tab = it }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                GlassCard(Modifier.fillMaxWidth(), onClick = { showCompose = true }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar("me", Red, 36.dp)
                        Text("  What's on your mind?", color = g.sub, modifier = Modifier.weight(1f))
                        Box(
                            Modifier.size(38.dp).clip(RoundedCornerShape(14.dp))
                                .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Red, Coral))),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
                    }
                }
            }
            error?.let { item { Text("Error: $it", color = Red, fontSize = 13.sp) } }
            if (loading && posts.isEmpty()) item {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Red)
                }
            }
            items(posts, key = { it.id }) { p ->
                PostCard(
                    p, onClick = { onOpenPost(p) },
                    onLike = {
                        val nl = !p.liked_by_me
                        posts = posts.map {
                            if (it.id == p.id) it.copy(liked_by_me = nl, like_count = it.like_count + (if (nl) 1 else -1)) else it
                        }
                        scope.launch { runCatching { Backend.setLike(p.id, nl) }.onFailure { load() } }
                    },
                    onReport = {
                        scope.launch {
                            runCatching { Backend.report("post", p.id) }
                                .onSuccess { Toast.makeText(ctx, "Reported. Thanks!", Toast.LENGTH_SHORT).show() }
                                .onFailure { Toast.makeText(ctx, "Could not report", Toast.LENGTH_SHORT).show() }
                        }
                    },
                    onDelete = {
                        scope.launch { runCatching { Backend.deletePost(p.id) }.onSuccess { load() } }
                    }
                )
            }
            if (!loading && posts.isEmpty() && error == null) item {
                EmptyNote(
                    if (tab == 2) "No posts from friends yet. Add some friends!" else "No posts yet. Be the first to post!",
                    if (tab == 2) "\uD83D\uDC4B" else "\u270D\uFE0F"
                )
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }

    if (showCompose) {
        Dialog(onDismissRequest = { showCompose = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            val shape = RoundedCornerShape(28.dp)
            Column(
                Modifier.fillMaxWidth().padding(16.dp).clip(shape)
                    .background(g.bg[0]).background(g.card).border(1.dp, g.borderHi, shape).padding(18.dp)
            ) {
                Text("New post", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = g.text)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    text, { if (it.length <= 2000) text = it },
                    placeholder = { Text("What's on your mind?") }, shape = RoundedCornerShape(18.dp),
                    colors = glassFieldColors(), modifier = Modifier.fillMaxWidth(), minLines = 4
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AnonSwitch(anon) { anon = it }
                    Spacer(Modifier.weight(1f))
                    Text("${text.length}/2000", color = g.sub, fontSize = 12.sp)
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { showCompose = false }) { Text("Cancel", color = g.sub) }
                    Spacer(Modifier.weight(1f))
                    SmallButton("Post", enabled = text.isNotBlank() && !posting) {
                        scope.launch {
                            posting = true
                            runCatching { Backend.createPost(text.trim(), anon) }
                                .onSuccess { text = ""; anon = false; showCompose = false; tab = 0; load() }
                                .onFailure { error = it.message; showCompose = false }
                            posting = false
                        }
                    }
                }
            }
        }
    }
}

private fun flatten(rs: List<ReplyRow>): List<Pair<ReplyRow, Int>> {
    val byParent = rs.groupBy { it.parent_reply_id }
    val out = mutableListOf<Pair<ReplyRow, Int>>()
    fun walk(parent: String?, depth: Int) {
        byParent[parent]?.forEach { out.add(it to depth); walk(it.id, depth + 1) }
    }
    walk(null, 0)
    return out
}

@Composable
fun PostDetailScreen(post: PostRow, onBack: () -> Unit) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var replies by remember { mutableStateOf<List<ReplyRow>>(emptyList()) }
    var replyTo by remember { mutableStateOf<ReplyRow?>(null) }
    var text by remember { mutableStateOf("") }
    var anon by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load() {
        scope.launch {
            runCatching { Backend.replies(post.id) }
                .onSuccess { replies = it; error = null }
                .onFailure { error = it.message }
        }
    }
    LaunchedEffect(post.id) { load() }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = g.text) }
            Text("Discussion", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = g.text)
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { PostCard(post, null, null) }
            item { Text("Replies", color = g.sub, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            error?.let { item { Text("Error: $it", color = Red, fontSize = 13.sp) } }
            items(flatten(replies), key = { it.first.id }) { (r, depth) ->
                val anonR = r.is_anonymous
                val name = if (anonR) "Anonymous" else "@" + (r.username ?: "user")
                GlassCard(Modifier.fillMaxWidth().padding(start = (minOf(depth, 4) * 16).dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(name, if (anonR) Yellow else Green, 30.dp, anonymous = anonR)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            name, color = if (anonR) Yellow else g.text,
                            fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                        )
                        Text(timeAgo(r.created_at), color = g.sub, fontSize = 12.sp)
                        Spacer(Modifier.width(6.dp))
                        ItemMenu(r.is_mine, onReport = {
                            scope.launch {
                                runCatching { Backend.report("reply", r.id) }
                                    .onSuccess { Toast.makeText(ctx, "Reported. Thanks!", Toast.LENGTH_SHORT).show() }
                            }
                        }, onDelete = {
                            scope.launch { runCatching { Backend.deleteReply(r.id) }.onSuccess { load() } }
                        })
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(r.body, color = g.text)
                    Text(
                        "Reply", color = Red, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp).clickable { replyTo = r }
                    )
                }
            }
            if (replies.isEmpty() && error == null) item { EmptyNote("No replies yet. Start the discussion!", "\uD83D\uDCAC") }
        }
        GlassCard(Modifier.fillMaxWidth().padding(10.dp).navigationBarsPadding()) {
            replyTo?.let {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Replying to " + (if (it.is_anonymous) "Anonymous" else "@" + (it.username ?: "user")),
                        color = Yellow, fontSize = 12.sp, modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { replyTo = null }) { Text("Cancel", color = g.sub) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    text, { if (it.length <= 1000) text = it },
                    placeholder = { Text("Write a reply...") }, shape = RoundedCornerShape(22.dp),
                    colors = glassFieldColors(), modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                SmallButton("Send", enabled = text.isNotBlank() && !sending) {
                    scope.launch {
                        sending = true
                        runCatching { Backend.addReply(post.id, replyTo?.id, text.trim(), anon) }
                            .onSuccess { text = ""; replyTo = null; load() }
                            .onFailure { error = it.message }
                        sending = false
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            AnonSwitch(anon) { anon = it }
        }
    }
}
