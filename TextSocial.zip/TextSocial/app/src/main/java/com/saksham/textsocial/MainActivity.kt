package com.saksham.textsocial

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.github.jan.supabase.auth.auth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        setContent {
            var mode by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
            AppTheme(mode) {
                Root(mode) { mode = it; prefs.edit().putInt("theme", it).apply() }
            }
        }
    }
}

@Composable
fun Root(themeMode: Int, setTheme: (Int) -> Unit) {
    var ready by remember { mutableStateOf(false) }
    var loggedIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        runCatching { Backend.client.auth.awaitInitialization() }
        loggedIn = Backend.uid != null
        ready = true
    }
    GlassBackground {
        when {
            !ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Red) }
            !loggedIn -> AuthScreen { loggedIn = true }
            else -> MainApp(themeMode, setTheme) { loggedIn = false }
        }
    }
}

@Composable
fun MainApp(themeMode: Int, setTheme: (Int) -> Unit, onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var post by remember { mutableStateOf<PostRow?>(null) }
    var chat by remember { mutableStateOf<ChatTarget?>(null) }

    BackHandler(enabled = post != null || chat != null) {
        if (chat != null) chat = null else post = null
    }

    val p = post
    val c = chat
    when {
        c != null -> ChatRoomScreen(c) { chat = null }
        p != null -> PostDetailScreen(p) { post = null }
        else -> Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen { post = it }
                    1 -> FriendsScreen()
                    2 -> MessagesScreen { chat = it }
                    3 -> NotificationsScreen()
                    else -> ProfileScreen(themeMode, setTheme, onLogout)
                }
            }
            BottomBar(tab) { tab = it }
        }
    }
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(26.dp)
    val items = listOf(
        "Home" to Icons.Filled.Home,
        "Friends" to Icons.Filled.Face,
        "Messages" to Icons.Filled.Email,
        "Alerts" to Icons.Filled.Notifications,
        "Profile" to Icons.Filled.Person
    )
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(shape).background(g.card).border(1.dp, g.border, shape).padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        items.forEachIndexed { i, (label, icon) ->
            val color = if (i == tab) Red else g.sub
            Column(
                Modifier.clip(RoundedCornerShape(16.dp)).clickable { onTab(i) }.padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, null, tint = color)
                Text(label, fontSize = 11.sp, color = color)
            }
        }
    }
}
