package com.saksham.textsocial

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import io.github.jan.supabase.auth.auth
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Notifier.init(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        setContent {
            var mode by remember { mutableIntStateOf(prefs.getInt("theme", 0)) }
            val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            SideEffect {
                val c = WindowCompat.getInsetsController(window, window.decorView)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }
            AppTheme(mode) {
                Root(mode) { mode = it; prefs.edit().putInt("theme", it).apply() }
            }
        }
    }
}

@Composable
fun Root(themeMode: Int, setTheme: (Int) -> Unit) {
    var ready by remember { mutableStateOf(false) }
    var loggedIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        runCatching { Backend.client.auth.awaitInitialization() }
        loggedIn = Backend.uid != null
        ready = true
    }
    GlassBackground {
        when {
            !ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Red) }
            !loggedIn -> AuthScreen { loggedIn = true }
            else -> MainApp(themeMode, setTheme) { loggedIn = false }
        }
    }
}

@Composable
fun MainApp(themeMode: Int, setTheme: (Int) -> Unit, onLogout: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var post by remember { mutableStateOf<PostRow?>(null) }
    var chat by remember { mutableStateOf<ChatTarget?>(null) }
    var notifs by remember { mutableStateOf<List<NotifItem>>(emptyList()) }
    var friendsStart by remember { mutableIntStateOf(0) }
    val openChatCid by rememberUpdatedState(chat?.cid)

    // Notification poller: every 6s check for new notifications, show system notification for new ones
    LaunchedEffect(Unit) {
        val seen = mutableSetOf<String>()
        var seeded = false
        while (true) {
            runCatching { Backend.notifications() }.onSuccess { list ->
                val fresh = list.filter { it.row.read_at == null && seen.add(it.row.id + it.row.created_at) }
                val autoRead = mutableListOf<String>()
                fresh.forEach { n ->
                    if (n.row.type == "message" && n.row.target_id == openChatCid) {
                        autoRead.add(n.row.id)
                    } else if (seeded) {
                        Notifier.show(ctx, (n.row.id + n.row.created_at).hashCode(), notifTitle(n), notifBody(n))
                    }
                }
                if (autoRead.isNotEmpty()) runCatching { Backend.markRead(autoRead) }
                notifs = if (autoRead.isEmpty()) list
                else list.map { if (it.row.id in autoRead) it.copy(row = it.row.copy(read_at = "now")) else it }
                seeded = true
            }
            delay(6000)
        }
    }

    fun refresh() {
        scope.launch { runCatching { Backend.notifications() }.onSuccess { notifs = it } }
    }

    fun openChat(c: ChatTarget) {
        chat = c
        val ids = notifs.filter { it.row.type == "message" && it.row.target_id == c.cid && it.row.read_at == null }.map { it.row.id }
        if (ids.isNotEmpty()) scope.launch { runCatching { Backend.markRead(ids) }; refresh() }
    }

    fun tapNotif(n: NotifItem) {
        scope.launch {
            if (n.row.read_at == null) runCatching { Backend.markRead(listOf(n.row.id)) }
            runCatching { Backend.notifications() }.onSuccess { notifs = it }
            when (n.row.type) {
                "like", "reply", "comment_reply" ->
                    n.row.target_id?.let { id -> runCatching { Backend.postById(id) }.getOrNull()?.let { post = it } }
                "friend_request" -> { friendsStart = 1; tab = 1 }
                "friend_accept" -> { friendsStart = 0; tab = 1 }
                "message" -> tab = 2
            }
        }
    }

    BackHandler(enabled = post != null || chat != null) {
        if (chat != null) chat = null else post = null
    }

    val unreadCount = notifs.count { it.row.read_at == null }
    val unreadConvs = notifs.filter { it.row.type == "message" && it.row.read_at == null }.mapNotNull { it.row.target_id }.toSet()

    val p = post
    val c = chat
    when {
        c != null -> ChatRoomScreen(c) { chat = null }
        p != null -> PostDetailScreen(p) { post = null }
        else -> Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen { post = it }
                    1 -> FriendsScreen(friendsStart) { openChat(it) }
                    2 -> MessagesScreen(unreadConvs) { openChat(it) }
                    3 -> NotificationsScreen(
                        notifs,
                        onMarkAll = {
                            val ids = notifs.filter { it.row.read_at == null }.map { it.row.id }
                            scope.launch { runCatching { Backend.markRead(ids) }; refresh() }
                        },
                        onTap = { tapNotif(it) }
                    )
                    else -> ProfileScreen(themeMode, setTheme, onLogout)
                }
            }
            BottomBar(tab, mapOf(2 to unreadConvs.size, 3 to unreadCount)) {
                if (it == 1) friendsStart = 0
                tab = it
                if (it == 3) refresh()
            }
        }
    }
}

@Composable
fun BottomBar(tab: Int, badges: Map<Int, Int>, onTab: (Int) -> Unit) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(28.dp)
    val items = listOf(
        "Home" to Icons.Filled.Home,
        "Friends" to Icons.Filled.Face,
        "Chats" to Icons.Filled.Email,
        "Alerts" to Icons.Filled.Notifications,
        "Profile" to Icons.Filled.Person
    )
    Row(
        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)
            .clip(shape).background(g.bg[0]).background(g.card).border(1.dp, g.borderHi, shape).padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        items.forEachIndexed { i, (label, icon) ->
            val sel = i == tab
            val color = if (sel) Red else g.sub
            val badge = badges[i] ?: 0
            Column(
                Modifier.clip(RoundedCornerShape(20.dp))
                    .background(if (sel) Red.copy(alpha = 0.16f) else androidx.compose.ui.graphics.Color.Transparent)
                    .clickable { onTab(i) }.padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box {
                    Icon(icon, null, tint = color)
                    if (badge > 0) Box(Modifier.align(Alignment.TopEnd).offset(8.dp, (-6).dp)) { CountBadge(badge) }
                }
                Text(label, fontSize = 11.sp, color = color)
            }
        }
    }
}
