package com.saksham.textsocial

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(onDone: () -> Unit) {
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var signup by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize().statusBarsPadding().imePadding(), contentAlignment = Alignment.Center) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Text Social", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Red)
            Text("Likho. Baato. Anonymous bhi.", color = g.sub)
            Spacer(Modifier.height(24.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    email, { email = it }, label = { Text("Email") }, singleLine = true,
                    colors = glassFieldColors(), modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
                if (signup) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        username, { username = it }, label = { Text("Username (a-z, 0-9, _)") }, singleLine = true,
                        colors = glassFieldColors(), modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    password, { password = it }, label = { Text("Password") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    colors = glassFieldColors(), modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                msg?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = Red, fontSize = 13.sp)
                }
                Spacer(Modifier.height(14.dp))
                SmallButton(if (signup) "Sign up" else "Login", enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    scope.launch {
                        busy = true; msg = null
                        runCatching {
                            if (signup) {
                                require(Regex("^[a-zA-Z0-9_]{3,20}$").matches(username.trim())) { "Username 3-20 chars: letters, numbers, _" }
                                require(password.length >= 6) { "Password kam se kam 6 characters ka rakho" }
                                Backend.signUp(email.trim(), password, username.trim())
                            } else {
                                Backend.signIn(email.trim(), password)
                            }
                        }.onSuccess {
                            if (Backend.uid != null) onDone() else msg = "Email confirm karo, fir login karo."
                        }.onFailure { msg = it.message ?: "Kuch gadbad hui" }
                        busy = false
                    }
                }
                TextButton(onClick = { signup = !signup; msg = null }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text(if (signup) "Account hai? Login karo" else "Naya account banao", color = Yellow)
                }
            }
        }
    }
}
