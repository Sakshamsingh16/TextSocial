package com.saksham.textsocial

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(onDone: () -> Unit) {
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var signup by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val fieldShape = RoundedCornerShape(16.dp)

    Box(Modifier.fillMaxSize().statusBarsPadding().imePadding(), contentAlignment = Alignment.Center) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("\uD83D\uDCAC", fontSize = 54.sp)
            BrandText("Text Social", 40.sp)
            Text("Write. Discuss. Stay anonymous if you want.", color = g.sub, fontSize = 13.sp)
            Spacer(Modifier.height(26.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                PillTabs(listOf("Login", "Sign up"), if (signup) 1 else 0) { signup = it == 1; msg = null }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    email, { email = it }, label = { Text("Email") }, singleLine = true, shape = fieldShape,
                    colors = glassFieldColors(), modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
                if (signup) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        username, { username = it }, label = { Text("Username (a-z, 0-9, _)") }, singleLine = true,
                        shape = fieldShape, colors = glassFieldColors(), modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    password, { password = it }, label = { Text("Password") }, singleLine = true, shape = fieldShape,
                    visualTransformation = PasswordVisualTransformation(),
                    colors = glassFieldColors(), modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )
                msg?.let {
                    Spacer(Modifier.height(10.dp))
                    Text(it, color = Red, fontSize = 13.sp)
                }
                Spacer(Modifier.height(16.dp))
                SmallButton(if (signup) "Create account" else "Login", enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    scope.launch {
                        busy = true; msg = null
                        runCatching {
                            if (signup) {
                                require(Regex("^[a-zA-Z0-9_]{3,20}$").matches(username.trim())) { "Username 3-20 chars: letters, numbers, _" }
                                require(password.length >= 6) { "Password must be at least 6 characters" }
                                Backend.signUp(email.trim(), password, username.trim())
                            } else {
                                Backend.signIn(email.trim(), password)
                            }
                        }.onSuccess {
                            if (Backend.uid != null) onDone() else msg = "Confirm your email, then login."
                        }.onFailure { msg = it.message ?: "Something went wrong" }
                        busy = false
                    }
                }
            }
        }
    }
}
