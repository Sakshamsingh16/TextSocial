package com.saksham.textsocial

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun NotificationsScreen() {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ScreenTitle("Alerts")
        EmptyNote("Notifications jaldi aayengi (likes, replies, friend requests).")
    }
}

@Composable
fun ProfileScreen(themeMode: Int, setTheme: (Int) -> Unit, onLogout: () -> Unit) {
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var me by remember { mutableStateOf<ProfileRow?>(null) }
    var displayName by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        runCatching { Backend.me() }
            .onSuccess { me = it; displayName = it.display_name ?: ""; bio = it.bio ?: "" }
            .onFailure { info = it.message }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
        ScreenTitle("Profile")
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(me?.username ?: "?")
                    Text("   @" + (me?.username ?: "..."), color = g.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    displayName, { if (it.length <= 40) displayName = it }, label = { Text("Display name") },
                    singleLine = true, colors = glassFieldColors(), modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    bio, { if (it.length <= 200) bio = it }, label = { Text("Bio") },
                    colors = glassFieldColors(), modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                SmallButton("Save", Green) {
                    scope.launch {
                        runCatching { Backend.saveProfile(displayName.trim(), bio.trim()) }
                            .onSuccess { info = "Saved" }.onFailure { info = it.message }
                    }
                }
                info?.let { Text(it, color = Yellow, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("Theme", color = g.text, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Auto", "Day", "Night").forEachIndexed { i, label ->
                        val sel = themeMode == i
                        Box(
                            Modifier.clip(RoundedCornerShape(14.dp))
                                .background(if (sel) Red else g.card)
                                .clickable { setTheme(i) }
                                .padding(horizontal = 18.dp, vertical = 8.dp)
                        ) { Text(label, color = if (sel) Color.White else g.text, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }

            SmallButton("Logout", Red, modifier = Modifier.fillMaxWidth()) {
                scope.launch { runCatching { Backend.signOut() }; onLogout() }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
