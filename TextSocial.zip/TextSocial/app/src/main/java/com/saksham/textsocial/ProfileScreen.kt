package com.saksham.textsocial

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun StatBox(value: String, label: String, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(g.card).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = g.text, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        Text(label, color = g.sub, fontSize = 12.sp)
    }
}

@Composable
fun ProfileScreen(themeMode: Int, setTheme: (Int) -> Unit, onLogout: () -> Unit) {
    val g = LocalGlass.current
    val scope = rememberCoroutineScope()
    var me by remember { mutableStateOf<ProfileRow?>(null) }
    var displayName by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var info by remember { mutableStateOf<String?>(null) }
    var posts by remember { mutableIntStateOf(0) }
    var friends by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        runCatching { Backend.me() }
            .onSuccess { me = it; displayName = it.display_name ?: ""; bio = it.bio ?: "" }
            .onFailure { info = it.message }
        runCatching { posts = Backend.myPostCount(); friends = Backend.friends().size }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState())) {
        ScreenTitle("Profile")
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(me?.username ?: "?", Red, 84.dp)
                    Spacer(Modifier.height(10.dp))
                    Text("@" + (me?.username ?: "..."), color = g.text, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    if (bio.isNotBlank()) Text(bio, color = g.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatBox("$posts", "Posts", Modifier.weight(1f))
                        StatBox("$friends", "Friends", Modifier.weight(1f))
                    }
                }
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("Edit profile", color = g.text, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    displayName, { if (it.length <= 40) displayName = it }, label = { Text("Display name") },
                    singleLine = true, shape = RoundedCornerShape(16.dp),
                    colors = glassFieldColors(), modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    bio, { if (it.length <= 200) bio = it }, label = { Text("Bio") }, shape = RoundedCornerShape(16.dp),
                    colors = glassFieldColors(), modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                SmallButton("Save", Green) {
                    scope.launch {
                        runCatching { Backend.saveProfile(displayName.trim(), bio.trim()) }
                            .onSuccess { info = "Saved" }.onFailure { info = it.message }
                    }
                }
                info?.let { Text(it, color = Yellow, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
            }

            GlassCard(Modifier.fillMaxWidth()) {
                Text("Theme", color = g.text, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                PillTabs(listOf("Auto", "Day", "Night"), themeMode, setTheme)
            }

            SmallButton("Logout", Red, modifier = Modifier.fillMaxWidth()) {
                scope.launch { runCatching { Backend.signOut() }; onLogout() }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
