package com.saksham.textsocial

import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

@Serializable data class ProfileRow(val id: String, val username: String, val display_name: String? = null, val bio: String? = null)

@Serializable data class PostRow(
    val id: String, val body: String, val created_at: String, val is_anonymous: Boolean,
    val author_id: String? = null, val display_name: String? = null, val username: String? = null,
    val like_count: Long = 0, val reply_count: Long = 0,
    val liked_by_me: Boolean = false, val is_mine: Boolean = false
)

@Serializable data class ReplyRow(
    val id: String, val post_id: String, val parent_reply_id: String? = null, val body: String,
    val created_at: String, val is_anonymous: Boolean, val author_id: String? = null,
    val display_name: String? = null, val username: String? = null, val is_mine: Boolean = false
)

@Serializable data class NewPost(val author_id: String, val body: String, val is_anonymous: Boolean)
@Serializable data class NewReply(val post_id: String, val author_id: String, val parent_reply_id: String?, val body: String, val is_anonymous: Boolean)
@Serializable data class LikeRow(val user_id: String, val post_id: String)
@Serializable data class FriendReqRow(val id: String, val sender_id: String, val receiver_id: String, val status: String)
@Serializable data class NewFriendReq(val sender_id: String, val receiver_id: String)
@Serializable data class FriendshipRow(val user_low_id: String, val user_high_id: String)
@Serializable data class ConvMemberRow(val conversation_id: String, val user_id: String)
@Serializable data class MessageRow(val id: String, val conversation_id: String, val sender_id: String, val body: String, val created_at: String)
@Serializable data class NewMessage(val conversation_id: String, val sender_id: String, val body: String)
@Serializable data class BlockRow(val blocker_id: String, val blocked_id: String)

@Serializable data class NotifRow(
    val id: String, val user_id: String, val type: String, val actor_id: String? = null,
    val target_id: String? = null, val preview: String? = null, val read_at: String? = null, val created_at: String
)
@Serializable data class NewReport(val reporter_id: String, val target_type: String, val target_id: String, val reason: String)

data class NotifItem(val row: NotifRow, val actor: String?)
data class ChatTarget(val cid: String, val name: String, val userId: String)

// Publishable key app me rakhna safe hai (security RLS se aati hai). Secret/service_role key yahan kabhi nahi.
private const val SUPABASE_URL = "https://ytyngasnktznrnpjiqwu.supabase.co"
private const val SUPABASE_KEY = "sb_publishable_9BZR-BbxFwrdl9tlbTPnLw_LJA6yPvJ"

object Backend {
    val client = createSupabaseClient(SUPABASE_URL, SUPABASE_KEY) {
        install(Auth)
        install(Postgrest)
    }

    val uid: String? get() = client.auth.currentUserOrNull()?.id

    // ---------- Auth ----------
    suspend fun signUp(email: String, password: String, username: String) {
        client.auth.signUpWith(Email) {
            this.email = email
            this.password = password
            data = buildJsonObject {
                put("username", username)
                put("display_name", username)
            }
        }
    }

    suspend fun signIn(email: String, password: String) {
        client.auth.signInWith(Email) {
            this.email = email
            this.password = password
        }
    }

    suspend fun signOut() = client.auth.signOut()

    // ---------- Profile ----------
    suspend fun me(): ProfileRow =
        client.from("profiles").select { filter { eq("id", uid!!) } }.decodeSingle<ProfileRow>()

    suspend fun saveProfile(displayName: String, bio: String) {
        client.from("profiles").update({
            set("display_name", displayName)
            set("bio", bio)
        }) { filter { eq("id", uid!!) } }
    }

    suspend fun profilesByIds(ids: List<String>): List<ProfileRow> =
        if (ids.isEmpty()) emptyList()
        else client.from("profiles").select { filter { isIn("id", ids) } }.decodeList<ProfileRow>()

    suspend fun searchUsers(q: String): List<ProfileRow> {
        val me = uid ?: return emptyList()
        if (q.isBlank()) return emptyList()
        return client.from("profiles").select {
            filter {
                ilike("username", "%$q%")
                neq("id", me)
            }
            limit(20)
        }.decodeList<ProfileRow>()
    }

    // ---------- Posts ----------
    suspend fun feed(): List<PostRow> =
        client.from("posts_public").select {
            order("created_at", Order.DESCENDING)
            limit(50)
        }.decodeList<PostRow>()

    suspend fun createPost(body: String, anonymous: Boolean) {
        client.from("posts").insert(NewPost(uid!!, body, anonymous))
    }

    suspend fun setLike(postId: String, like: Boolean) {
        val me = uid ?: return
        if (like) client.from("post_likes").insert(LikeRow(me, postId))
        else client.from("post_likes").delete {
            filter {
                eq("user_id", me)
                eq("post_id", postId)
            }
        }
    }

    // ---------- Replies ----------
    suspend fun replies(postId: String): List<ReplyRow> =
        client.from("replies_public").select {
            filter { eq("post_id", postId) }
            order("created_at", Order.ASCENDING)
        }.decodeList<ReplyRow>()

    suspend fun addReply(postId: String, parentId: String?, body: String, anonymous: Boolean) {
        client.from("replies").insert(NewReply(postId, uid!!, parentId, body, anonymous))
    }

    // ---------- Friends ----------
    suspend fun sendRequest(toUserId: String) {
        client.from("friend_requests").insert(NewFriendReq(uid!!, toUserId))
    }

    suspend fun incomingRequests(): List<Pair<FriendReqRow, ProfileRow?>> {
        val me = uid ?: return emptyList()
        val reqs = client.from("friend_requests").select {
            filter {
                eq("receiver_id", me)
                eq("status", "pending")
            }
        }.decodeList<FriendReqRow>()
        val profiles = profilesByIds(reqs.map { it.sender_id }).associateBy { it.id }
        return reqs.map { it to profiles[it.sender_id] }
    }

    suspend fun respond(requestId: String, status: String) {
        client.from("friend_requests").update({ set("status", status) }) {
            filter { eq("id", requestId) }
        }
    }

    suspend fun friends(): List<ProfileRow> {
        val me = uid ?: return emptyList()
        val rows = client.from("friendships").select().decodeList<FriendshipRow>()
        val ids = rows.map { if (it.user_low_id == me) it.user_high_id else it.user_low_id }
        return profilesByIds(ids)
    }

    suspend fun block(userId: String) {
        val me = uid ?: return
        client.from("blocks").insert(BlockRow(me, userId))
        runCatching {
            client.from("friendships").delete {
                filter {
                    eq("user_low_id", minOf(me, userId))
                    eq("user_high_id", maxOf(me, userId))
                }
            }
        }
    }

    // ---------- Chat ----------
    suspend fun chats(): List<ChatTarget> {
        val me = uid ?: return emptyList()
        val others = client.from("conversation_members").select {
            filter { neq("user_id", me) }
        }.decodeList<ConvMemberRow>()
        val profiles = profilesByIds(others.map { it.user_id }).associateBy { it.id }
        return others.map {
            ChatTarget(it.conversation_id, profiles[it.user_id]?.username ?: "user", it.user_id)
        }
    }

    // newest first
    suspend fun messages(cid: String): List<MessageRow> =
        client.from("messages").select {
            filter { eq("conversation_id", cid) }
            order("created_at", Order.DESCENDING)
            limit(100)
        }.decodeList<MessageRow>()

    suspend fun sendMessage(cid: String, body: String) {
        client.from("messages").insert(NewMessage(cid, uid!!, body))
    }
    // ---------- Feed variants ----------
    suspend fun feedFriends(friendIds: List<String>): List<PostRow> =
        if (friendIds.isEmpty()) emptyList()
        else client.from("posts_public").select {
            filter { isIn("author_id", friendIds) }
            order("created_at", Order.DESCENDING)
            limit(50)
        }.decodeList<PostRow>()

    suspend fun postById(id: String): PostRow? =
        client.from("posts_public").select {
            filter { eq("id", id) }
            limit(1)
        }.decodeList<PostRow>().firstOrNull()

    suspend fun myPostCount(): Int =
        client.from("posts_public").select { filter { eq("is_mine", true) } }.decodeList<PostRow>().size

    suspend fun deletePost(id: String) {
        client.from("posts").update({ set("deleted_at", java.time.Instant.now().toString()) }) {
            filter { eq("id", id) }
        }
    }

    suspend fun deleteReply(id: String) {
        client.from("replies").update({ set("deleted_at", java.time.Instant.now().toString()) }) {
            filter { eq("id", id) }
        }
    }

    suspend fun report(type: String, id: String, reason: String = "Reported by user") {
        client.from("reports").insert(NewReport(uid!!, type, id, reason))
    }

    // ---------- Notifications ----------
    suspend fun notifications(): List<NotifItem> {
        val me = uid ?: return emptyList()
        val rows = client.from("notifications").select {
            filter { eq("user_id", me) }
            order("created_at", Order.DESCENDING)
            limit(60)
        }.decodeList<NotifRow>()
        val names = profilesByIds(rows.mapNotNull { it.actor_id }.distinct()).associateBy { it.id }
        return rows.map { n -> NotifItem(n, n.actor_id?.let { names[it]?.username }) }
    }

    suspend fun markRead(ids: List<String>) {
        if (ids.isEmpty()) return
        client.from("notifications").update({ set("read_at", java.time.Instant.now().toString()) }) {
            filter { isIn("id", ids) }
        }
    }
}
