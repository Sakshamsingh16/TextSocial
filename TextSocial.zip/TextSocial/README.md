# Text Social (Android)
Kotlin + Jetpack Compose + Supabase. Red / Green / Yellow glass theme, Day + Night.
Supabase URL aur publishable key `Backend.kt` ke top me hain.
